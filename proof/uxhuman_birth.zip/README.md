# UXHuman – Open Source Initiative
**© Mauricio Aristizabal — 05-05-2025**

Canonical repository under the `UXHuman-org` organisation.  
Domains: UXHuman.com • UXHuman.io • UXHuman.org

## Purpose
Establish an open framework for human-centred conversational UX.
